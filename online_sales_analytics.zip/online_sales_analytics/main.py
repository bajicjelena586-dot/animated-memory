"""Pokretanje primjera za online prodaju."""

from proizvod import Proizvod
from proizvod_menadzer import ProductManager
from korpa import Cart


def main() -> None:
    menadzer = ProductManager()

    laptop = Proizvod("Laptop", 1250.00, 5)
    slusalice = Proizvod("Slušalice", 65.50, 12)
    mis = Proizvod("Bežični miš", 32.90, 20)

    for proizvod in (laptop, slusalice, mis):
        menadzer.dodaj_proizvod(proizvod)

    menadzer.prikazi_proizvode()
    print(f"Ukupna vrijednost inventara: "
          f"{menadzer.ukupna_vrednost_inventara():.2f} KM")

    # Primjer uklanjanja proizvoda po nazivu:
    # if menadzer.ukloni_proizvod("Slušalice"):
    #     print("Proizvod je uklonjen.")

    korpa = Cart()
    korpa.dodaj_proizvod(laptop)
    korpa.dodaj_proizvod(slusalice)
    korpa.dodaj_proizvod(slusalice)
    korpa.prikazi_korpu()

    print("\n--- Inventar nakon kupovine ---")
    menadzer.prikazi_proizvode()
    print(f"Preostala vrijednost inventara: "
          f"{menadzer.ukupna_vrednost_inventara():.2f} KM")


if __name__ == "__main__":
    main()
