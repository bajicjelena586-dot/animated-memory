"""Korpa kupca."""

from proizvod import Proizvod


class Cart:
    def __init__(self):
        self.cart_items: list[Proizvod] = []

    def dodaj_proizvod(self, proizvod: Proizvod) -> None:
        if proizvod.kolicina <= 0:
            raise ValueError(f"Proizvod {proizvod.naziv} nije dostupan na zalihama.")
        # U korpi se čuva jedan komad proizvoda po dodavanju.
        self.cart_items.append(Proizvod(proizvod.naziv, proizvod.cena, 1))
        proizvod.azuriranje_kolicine(proizvod.kolicina - 1)

    def ukupna_vrednost(self) -> float:
        return sum(proizvod.cena * proizvod.kolicina for proizvod in self.cart_items)

    def prikazi_korpu(self) -> None:
        if not self.cart_items:
            print("Korpa je prazna.")
            return
        print("\n--- Sadržaj korpe ---")
        for proizvod in self.cart_items:
            print(f"{proizvod.naziv} x {proizvod.kolicina} — {proizvod.cena:.2f} KM")
        print(f"Ukupno za naplatu: {self.ukupna_vrednost():.2f} KM")
