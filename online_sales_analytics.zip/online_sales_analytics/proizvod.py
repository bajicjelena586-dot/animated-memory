"""Model proizvoda za jednostavan sistem prodaje."""


class Proizvod:
    def __init__(self, naziv: str, cena: float, kolicina: int):
        if not naziv.strip():
            raise ValueError("Naziv proizvoda ne smije biti prazan.")
        if cena < 0:
            raise ValueError("Cijena ne može biti negativna.")
        if kolicina < 0:
            raise ValueError("Količina ne može biti negativna.")

        self.naziv = naziv
        self.cena = float(cena)
        self.kolicina = int(kolicina)

    def prikaz_info(self) -> str:
        return (
            f"Proizvod: {self.naziv} | Cijena: {self.cena:.2f} KM | "
            f"Količina: {self.kolicina}"
        )

    def azuriranje_kolicine(self, nova_kolicina: int) -> None:
        if nova_kolicina < 0:
            raise ValueError("Količina ne može biti negativna.")
        self.kolicina = int(nova_kolicina)

    def vrednost_zaliha(self) -> float:
        return self.cena * self.kolicina
