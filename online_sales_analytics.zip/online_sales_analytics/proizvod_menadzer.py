"""Upravljanje listom proizvoda i zalihama."""

from proizvod import Proizvod


class ProductManager:
    def __init__(self):
        self.proizvodi: list[Proizvod] = []

    def dodaj_proizvod(self, proizvod: Proizvod) -> None:
        if not isinstance(proizvod, Proizvod):
            raise TypeError("Može se dodati samo objekat klase Proizvod.")
        self.proizvodi.append(proizvod)

    def prikazi_proizvode(self) -> None:
        if not self.proizvodi:
            print("Nema proizvoda u inventaru.")
            return
        print("\n--- Proizvodi u inventaru ---")
        for proizvod in self.proizvodi:
            print(proizvod.prikaz_info())

    def ukupna_vrednost_inventara(self) -> float:
        return sum(proizvod.vrednost_zaliha() for proizvod in self.proizvodi)

    def ukloni_proizvod(self, naziv: str) -> bool:
        """Uklanja prvi proizvod sa zadatim nazivom; vraća True ako je pronađen."""
        for indeks, proizvod in enumerate(self.proizvodi):
            if proizvod.naziv.casefold() == naziv.casefold():
                del self.proizvodi[indeks]
                return True
        return False
