# Online Sales Analytics

Jednostavan Python projekat za upravljanje proizvodima, zalihama i korpom kupca. Projekat je napravljen kao vježba rada sa klasama, Git granama i GitHub repozitorijumom.

## Funkcionalnosti

- `Proizvod`: čuva naziv, cijenu i količinu; prikazuje informacije i ažurira količinu.
- `ProductManager`: dodaje i prikazuje proizvode, računa ukupnu vrijednost inventara i uklanja proizvod po nazivu.
- `Cart`: dodaje proizvode u korpu, umanjuje stanje zaliha, prikazuje sadržaj i računa iznos za naplatu.
- `main.py`: demonstrira rad svih klasa.

## Pokretanje

Potrebno je instalirati Python 3.10 ili noviji. U terminalu, iz direktorijuma projekta pokrenuti:

```bash
python main.py
```

Na nekim sistemima koristi se `python3 main.py`.

## Struktura projekta

```text
online_sales_analytics/
├── .gitignore
├── README.md
├── config.json
├── proizvod.py
├── proizvod_menadzer.py
├── korpa.py
├── main.py
└── screenshots/
```

## Git i GitHub — koraci za predaju

1. Napraviti prazan GitHub repozitorijum pod nazivom `online_sales_analytics`.
2. Otvoriti terminal u ovom direktorijumu i izvršiti:

```bash
git init
git config user.name "Tvoje Ime"
git config user.email "tvoj-email@example.com"
git add .
git status
git commit -m "Dodaj osnovnu analitiku online prodaje"
git branch -M main
git remote add origin https://github.com/TVOJE-KORISNICKO-IME/online_sales_analytics.git
git push -u origin main
```

Zamijeni ime, email i URL repozitorijuma svojim podacima. Ako si već povezala Git identitet, komande `git config` mogu se preskočiti.

### Rad sa granama

Za vježbu uklanjanja proizvoda:

```bash
git switch -c add-product-removal
```

Implementacija metode `ukloni_proizvod` nalazi se u `proizvod_menadzer.py`. Nakon provjere:

```bash
git add proizvod_menadzer.py main.py
git commit -m "Dodaj uklanjanje proizvoda"
git switch main
git merge add-product-removal
git push
```

Za funkcionalnost korpe:

```bash
git switch -c add-cart-functionality
git add korpa.py main.py
git commit -m "Dodaj funkcionalnost korpe"
git switch main
git merge add-cart-functionality
git push
```

Ako Git prijavi konflikt, otvori navedene fajlove, ukloni oznake konflikta (`<<<<<<<`, `=======`, `>>>>>>>`), sačuvaj ispravan kod, pa izvrši `git add .` i `git commit`.

## Konfiguracija i privatni podaci

`config.json` je namjerno naveden u `.gitignore` i ne treba da bude poslat na GitHub. U ovom zadatku sadrži samo probne vrijednosti. Ne stavljaj stvarne API ključeve, lozinke ili druge tajne u repozitorijum.

## Snimci ekrana za predaju

U direktorijum `screenshots/` dodaj svoje stvarne snimke ekrana:
- `01-git-status.png` — terminal nakon `git status` / commit-a;
- `02-github-repository.png` — repozitorijum otvoren u internet pregledaču;
- `03-project-running.png` — izlaz komande `python main.py`.

Snimci moraju biti napravljeni na tvom računaru nakon što izvršiš komande i postaviš projekat na svoj GitHub nalog. Nemoj slati izmišljene snimke.
