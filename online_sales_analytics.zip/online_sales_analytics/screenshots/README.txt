Ovdje dodaj stvarne snimke ekrana koje zadatak traži.
Ne mogu se unaprijed napraviti autentični snimci tvog Git terminala ili tvog GitHub naloga.
